# TSF Bank 🏦


[Launch TSF Bank](http://tsfbank.rf.gd) 🏦

[![PRs Welcome](https://img.shields.io/badge/PRs-Welcome-brightgreen.svg?style=flat&logo=github)](https://github.com/jigar-sable/TSF-Bank)&nbsp;
![contributions welcome](https://img.shields.io/static/v1.svg?label=Contributions&message=Welcome&color=brightgreen&style=flat&logo=github)&nbsp;
[![first-timers-only](https://img.shields.io/badge/first--timers--only-friendly-blue.svg?style=flat)](https://github.com/jigar-sable/TSF-Bank)&nbsp;
[![tsf-bank](https://img.shields.io/website-up-down-green-red/http/shields.io.svg?color=blue)](http://tsfbank.rf.gd)&nbsp;
[![repo-size](https://img.shields.io/github/repo-size/jigar-sable/TSF-Bank)](https://github.com/jigar-sable/TSF-Bank)




## Overview

Basic Banking System based on PHP and MySQL database.
Made with basic HTML, CSS, JavaScript and backend with PHP.

## Tech Stack
[![HTML](https://img.shields.io/badge/html5%20-%23E34F26.svg?&style=for-the-badge&logo=html5&logoColor=white)](https://github.com/jigar-sable/TSF-Bank/search?l=html)&nbsp;
[![CSS](https://img.shields.io/badge/css3%20-%231572B6.svg?&style=for-the-badge&logo=css3&logoColor=white)](https://github.com/jigar-sable/TSF-Bank/search?l=css)&nbsp;
[![JS](https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E)](https://github.com/jigar-sable/TSF-Bank/search?l=javascript)
[![bs](https://img.shields.io/badge/Bootstrap-563D7C?style=for-the-badge&logo=bootstrap&logoColor=white)]()
[![php](https://img.shields.io/badge/PHP-777BB4?style=for-the-badge&logo=php&logoColor=white)](https://github.com/jigar-sable/TSF-Bank/search?l=php)
[![mysql](https://img.shields.io/badge/MySQL-00000F?style=for-the-badge&logo=mysql&logoColor=white)]()

## Sneak Peek of Home Page 🙈 :
![thumb1](https://user-images.githubusercontent.com/64949957/121956544-e1a21000-cd7e-11eb-9ae0-8096ba7b765f.PNG)
![thumb2](https://user-images.githubusercontent.com/64949957/121956614-fa122a80-cd7e-11eb-9311-d425885c1bf1.PNG)

<h2>📬 Contact</h2>

If you want to contact me, you can reach me through below handles.

&nbsp;&nbsp;<a href="https://www.linkedin.com/in/jigar-sable/"><img src="https://www.felberpr.com/wp-content/uploads/linkedin-logo.png" width="30"></img></a>

© 2021 Jigar Sable


[![forthebadge](https://forthebadge.com/images/badges/built-with-love.svg)](https://forthebadge.com) 
[![forthebadge](https://forthebadge.com/images/badges/built-by-developers.svg)](https://forthebadge.com) 
[![forthebadge](https://forthebadge.com/images/badges/built-with-swag.svg)](https://forthebadge.com)

