<header>
        <a href="index.php" class="logo">TSF Bank</a>

        <div id="menu-bar" class="fas fa-bars"></div>
        <nav class="navbar">
            <a href="index.php">Home</a>
            <a href="viewuser.php">View Users</a>
            <a href="transfer.php">Transfer Money</a>
            <a href="transhistory.php">Transaction History</a>
            <a href="index.php#contact" class="conbtn">Contact Us</a>
        </nav>
</header>